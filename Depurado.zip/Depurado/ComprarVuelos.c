int ComprarVuelos();

int ComprarVuelos(){
	FILE *listaVuelos;

	char aeropuertoSalida[100], aeropuertoLlegada[100];
	int resultadoComprobacion=0;

	CLEAR	
	p("\n\tBienvenido al sistema de compra\n");
	p("\n\tA continuacion se presentaran los vuelos disponibles\n");
	getchar(); FLUSH
	system("gnome-terminal -x sh -c ./OrdenarVuelos & disown"); CLEAR
	
	p("\n\tPara conocer vuelos, ingrese aeropuerto de salida:\n\n\t");
	s(" %[^\n]%*c",&aeropuertoSalida); FLUSH
        resultadoComprobacion=FuncionComprobarVuelo(aeropuertoSalida);
	if(resultadoComprobacion!=1){
		p("\n\tEl aeropuerto de salida ingresado no existe\n");
		p("\n\tIntente de nuevo\n");
		getchar(); FLUSH CLEAR
	}else{
		p("\n\tIngresar aeropuerto de llegada\n\n\t");
		s(" %[^\n]%*c",&aeropuertoLlegada); FLUSH
		resultadoComprobacion=FuncionComprobarVuelo(aeropuertoLlegada);
		if(resultadoComprobacion!=2){
			p("\n\tEl aeropuerto de llegada ingresado no existe\n");
			p("\n\tIntente de nuevo\n");
			getchar(); FLUSH CLEAR		
		}else{
			
		}
	}
	

	
	return 0;
}
