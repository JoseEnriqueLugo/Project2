int ComprarVuelos(int opcion);
int ImprimirVueloSeleccionado(char salida[],char llegada[]);
int ComprarBoleto();
int ComprarVuelos(){
	FILE *listaVuelos;

	char aeropuertoSalida[100], aeropuertoLlegada[100];
	int resultadoComprobacion=0, resultadoVuelos, opcion=0, opcionValida=0, regresoCompra=0;

	CLEAR	
	p("\n\tBienvenido al sistema de compra\n");
	p("\n\tA continuacion se presentaran los vuelos disponibles\n");
	getchar(); FLUSH
//	system("gnome-terminal -x sh -c ./OrdenarVuelos & disown"); CLEAR
	
	p("\n\tPara conocer vuelos, ingrese aeropuerto de salida:\n\n\t");
	s(" %[^\n]%*c",&aeropuertoSalida); FLUSH
	p("\n\tIngresar aeropuerto de llegada\n\n\t");
	s(" %[^\n]%*c",&aeropuertoLlegada); FLUSH
	resultadoComprobacion=FuncionComprobarVuelo(aeropuertoSalida,aeropuertoLlegada);
		if(resultadoComprobacion!=1){
			p("\n\tEl aeropuerto de llegada ingresado no existe\n");
			p("\n\tIntente de nuevo\n");
			getchar(); FLUSH CLEAR		
		}else{
			resultadoVuelos=ImprimirVueloSeleccionado(aeropuertoSalida,aeropuertoLlegada);
			p("\nIndique la opcion a realizar\n");
			opcionValida=0;
			while(opcionValida==0){
				
				for(opcion=1; opcion<resultadoVuelos; opcion++){
					p("\n\t\t%i.Comprar boletos para opcion %i de vuelo.\n",opcion,opcion);
				}
				p("\n\t\t%i.Cancelar compra\n",opcion);
				s(" %i",&opcion); FLUSH
				if(opcion>=1&&opcion<=resultadoVuelos+1){
					opcionValida=1;
				}
				CLEAR
				p("\nIndique la opcion a realizar\n");
			}
			if(opcion==resultadoVuelo+1){
			}else{
				regresoCompra=ComprarBoletos(opcion);
			}
			
			
			
		
	}
	

	
	return 0;
}


int ImprimirVueloSeleccionado(char salida[],char llegada[]){


	FILE *archivo;
	archivo=fopen("CodigoVuelos.txt","r");
	int posicion, indice, indiceR, indiceC, contador=1;
	char cadena[200], segmento[100][100];

//	p("\nSe logro transferencia %s y %s \n",salida,llegada);
	CLEAR
	if(archivo!=NULL){
		fseek(archivo,0,SEEK_END);
		posicion=ftell(archivo);
		rewind(archivo);
		while(feof(archivo)==0&&ftell(archivo)!=posicion){
		
			fgets(cadena,200,archivo);
			indiceR=0; indiceC=0;
			for(indice=0; indice<strlen(cadena);indice++){
				if(cadena[indice]=='-'&&indice!=0){
					segmento[indiceR][indiceC]='\0';
					indiceR++;
					indiceC=0;
				}else{
					segmento[indiceR][indiceC]=cadena[indice];
					indiceC++;
				}	
			}
			segmento[indiceR][indiceC-1]='\0';
			if(strcmp(segmento[1],salida)==0&&strcmp(segmento[2],llegada)==0){
			
				p(GRN"\n\tOpcion %i"RESET" %s",contador,segmento[1]);
				p(" - %s\n"RESET,segmento[2]);
				p(CYN"\n\t\tDia de salida: "RESET" %s\n",segmento[3]);
				p(CYN"\n\t\tHora de salida: "RESET" %s\n",segmento[4]);
				p(CYN"\n\t\tDia de llegada: "RESET"%s\n",segmento[5]);
				p(CYN"\n\t\tHora de llegada; "RESET"%s\n",segmento[6]);
				p(CYN"\n\t\tPrecio: "RESET"%s\n",segmento[7]);
				p(CYN"\n\t\tCodigo de vuelo: "RESET"%s\n",segmento[0]);
				contador++;
				
	
			
			}


					


		}
		getchar(); FLUSH CLEAR		

	}
	
	return contador;

}

int ComprarBoleto(int vuelo){

	}
