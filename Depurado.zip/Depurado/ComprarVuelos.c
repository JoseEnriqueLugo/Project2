int ComprarVuelos();
int ImprimirVueloSeleccionado(char salida[],char llegada[]);
int ComprarVuelos(){
	FILE *listaVuelos;

	char aeropuertoSalida[100], aeropuertoLlegada[100];
	int resultadoComprobacion=0;

	CLEAR	
	p("\n\tBienvenido al sistema de compra\n");
	p("\n\tA continuacion se presentaran los vuelos disponibles\n");
	getchar(); FLUSH
//	system("gnome-terminal -x sh -c ./OrdenarVuelos & disown"); CLEAR
	
	p("\n\tPara conocer vuelos, ingrese aeropuerto de salida:\n\n\t");
	s(" %[^\n]%*c",&aeropuertoSalida); FLUSH
	p("\n\tIngresar aeropuerto de llegada\n\n\t");
	s(" %[^\n]%*c",&aeropuertoLlegada); FLUSH
	resultadoComprobacion=FuncionComprobarVuelo(aeropuertoSalida,aeropuertoLlegada);
		if(resultadoComprobacion!=1){
			p("\n\tEl aeropuerto de llegada ingresado no existe\n");
			p("\n\tIntente de nuevo\n");
			getchar(); FLUSH CLEAR		
		}else{
			ImprimirVueloSeleccionado(aeropuertoSalida,aeropuertoLlegada);
			
		
	}
	

	
	return 0;
}


int ImprimirVueloSeleccionado(char salida[],char llegada[]){


	FILE *archivo;
	archivo=fopen("CodigoVuelos.txt","r");
	int posicion, indice, indiceR, indiceC, contador=1;
	char cadena[150], segmento[100][100];

//	p("\nSe logro transferencia %s y %s \n",salida,llegada);
	CLEAR
	if(archivo!=NULL){
		fseek(archivo,0,SEEK_END);
		posicion=ftell(archivo);
		rewind(archivo);
		while(feof(archivo)==0&&ftell(archivo)!=posicion){
		
			fgets(cadena,150,archivo);
			indiceR=0; indiceC=0;
			for(indice=0; indice<strlen(cadena);indice++){
				if(cadena[indice]=='-'&&indice!=0){
					segmento[indiceR][indiceC]='\0';
					indiceR++;
					indiceC=0;
				}else{
					segmento[indiceR][indiceC]=cadena[indice];
					indiceC++;
				}	
			}
			segmento[indiceR][indiceC]='\0';
			if(strcmp(segmento[1],salida)==0&&strcmp(segmento[2],llegada)==0){
			
				p("\n\tOpcion %i de vuelo de %s",contador,segmento[1]);
				p("a %s\n",segmento[2]);
				p("\n\t\tDia de salida: %s\n",segmento[3]);
				p("\n\t\tHora de salida: %s\n",segmento[4]);
				p("\n\t\tDia de llegada: %s\n",segmento[5]);
				p("\n\t\tHora de llegada; %s\n",segmento[6]);
				p("\n\t\tPrecio: %s\n",segmento[7]);
				p("\n\t\tCodigo de vuelo: %s\n",segmento[0]);
				contador++;
				
	
			
			}


					


		}
		

	}
	
	return contador;

}


