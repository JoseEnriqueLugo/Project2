int FuncionComprobarVuelo(char aeropuerto[]);

int FuncionComprobarVuelo(char aeropuerto[]){
	 FILE *listaAeropuertos;
        listaAeropuertos=fopen("CodigoVuelos.txt","r");
        char cadena[200], arregloDeCadena[200][200], segmentoDeCadena[200][200];
        int indiceR=0, indice=0, indiceRsegmento=0, indiceCsegmento=0, subcadenas=0, posicion=0, aeropuertoExistente=0, regreso=0;



        p("\n\tSe logro transferencia de: %s\n",aeropuerto);


        if(listaAeropuertos==NULL){

        }else{
                fseek(listaAeropuertos,0,SEEK_END);
                posicion=ftell(listaAeropuertos);
                rewind(listaAeropuertos);

                while(feof(listaAeropuertos)==0&&ftell(listaAeropuertos)!=posicion){

                        fgets(cadena,200,listaAeropuertos);
                        for(indice=0; indice<strlen(cadena); indice++){
                                arregloDeCadena[indiceR][indice]=cadena[indice];
                        }
                        //p("\n\tCadena: %s**\n",arregloDeCadena[indiceR]);
                        indiceR++;
                        indiceRsegmento=0;
                        indiceCsegmento=0;
                        for(indice=0; indice<strlen(cadena); indice++){
                                if(cadena[indice]=='-'&&indice!=0){
                                        segmentoDeCadena[indiceRsegmento][indiceCsegmento]='\0';
                                        indiceRsegmento++;
                                        indiceCsegmento=0;
                                }else{
                                        segmentoDeCadena[indiceRsegmento][indiceCsegmento]=cadena[indice];
                                        indiceCsegmento++;
                                }
                        }


			subcadenas=indiceRsegmento;
                        segmentoDeCadena[indiceRsegmento][indiceCsegmento]='\0';
                        if(strcmp(segmentoDeCadena[1],aeropuerto)==0){
                                regreso=1;
				p("\nAeropuerto salida  %s\n",segmentoDeCadena[1]);
                       }else{
				if(strcmp(segmentoDeCadena[2],aeropuerto)==0){
					regreso=2;
				p("\nAeropuerto llegada  %s\n",segmentoDeCadena[2]);
				
				}else{
					regreso=0;
					p("\nAeropuerto ->%s\n",segmentoDeCadena[1]);
					p("\nAeropuerto <-%s\n",segmentoDeCadena[2]);
				}
			} 
                }
        }
        fclose(listaAeropuertos);
        return regreso;
}
                                                                                                                                  
