int RevisarVuelos();

int RevisarVuelos(){

	


	return 0;
}
