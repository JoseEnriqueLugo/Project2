#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define RED "\x1B[31m"
#define GRN "\x1B[32m"
#define CYN  "\x1B[36m"
#define RESET "\x1B[0m"



void main(){
	FILE *archivo=fopen("CodigoVuelos.txt","r");
	int posicion, indice, indiceR, indiceC, subcadena, opcion=0;
	char cadena[100], segmentos[100][100];
	

	system("clear");
	while(opcion==0){
	printf(GRN"\n\tPresionar ENTER para presentar lista de vuelos\n"RESET);		
	getchar(); setbuf(stdin, NULL);
	system("clear");
		if(archivo!=NULL){
			fseek(archivo,0,SEEK_END);
			posicion=ftell(archivo);
			rewind(archivo);
			//printf("\nSe pudo abrir archivo\n");
			printf("\n\tAeropuertos de Salida\t\t\tAeropuertos de Llegada\n");
			while(feof(archivo)==0&&ftell(archivo)!=posicion){
				
				fgets(cadena,100,archivo);
			//	printf("\nCadena: %s**\n",cadena);
				indiceR=0;
				indiceC=0;
				for(indice=0; indice<strlen(cadena);indice++){
					if(cadena[indice]=='-'&&indice!=0){
						segmentos[indiceR][indiceC]='\0';
						indiceR++;
						indiceC=0;
					}else{
						segmentos[indiceR][indiceC]=cadena[indice];
						indiceC++;
	
					}
	
				}
				segmentos[indiceR][indiceC]='\0';
				if(strlen(segmentos[1])>=10){
					if(strlen(segmentos[2])>=10){
						printf(CYN"\n\t%s\t\t%s\n"RESET,segmentos[1],segmentos[2]);
					}else{
						printf(CYN"\n\t%s\t\t\t\t%s\n"RESET,segmentos[1],segmentos[2]);
					}
				}
				else{
					if(strlen(segmentos[2])>=10){
						printf(CYN"\n\t\t%s\t\t\t\t%s\n"RESET,segmentos[1],segmentos[2]);
					}else{
						printf(CYN"\n\t\t%s\t\t\t\t\t%s\n"RESET,segmentos[1],segmentos[2]);
					}
				}

			}

		}
	getchar(); setbuf(stdin,NULL);
	}

		



}
